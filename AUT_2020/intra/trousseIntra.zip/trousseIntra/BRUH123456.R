# =======================================================================
# CodePerma         : ***********
# =======================================================================
# Dépôt de l'examen : Éxecutez la dernière ligne de ce script browseURL()
# DATE              : 2020-10-27 09:00
# COURS             : ACT3035
# SUJET             : Examen Intra
# =======================================================================

# 1) Dans la section ci-haut , veuillez saisir code perman à la place des (*****)
# 2) Renomer ce fichier avec votre code perman

# ============================ prob type de vehicule ================================
# =======================================================================




# ============================ prob maison montreal ================================
# =======================================================================
ggplot(data=...,aes(x=ConstructionYear,y=moyenne_price))+
  geom_smooth(color="grey40")+
  geom_point(color="red", size=.5)









# ============================ prob vecteur a pas dans b ================================
# =======================================================================
CompInterSection(a,b)


  


# ============================ prob variable aleatoire ================================
# =======================================================================

  
  
  
  
  
  
  
# ======================Déposez l'examen ===================================
# Exécutez la ligne suivante afin d'ouvrir le lien où vous déposer l'examen |
# ==========================================================================
browseURL("https://www.dropbox.com/request/LUIaXm9wBAkv6wKY3VxE")             









